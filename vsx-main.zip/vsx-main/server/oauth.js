const DEVICE_CODE_URL = process.env.GITHUB_OAUTH_DEVICE_URL || "https://github.com/login/device/code";
const ACCESS_TOKEN_URL = process.env.GITHUB_OAUTH_TOKEN_URL || "https://github.com/login/oauth/access_token";
const AUTHORIZE_URL = process.env.GITHUB_OAUTH_AUTHORIZE_URL || "https://github.com/login/oauth/authorize";
const GRANT_TYPE = "urn:ietf:params:oauth:grant-type:device_code";

/**
 * Fluxo de autorização do GitHub (OAuth device flow).
 *
 * O navegador não pode falar com github.com diretamente (CORS), então quem
 * faz as chamadas é a ponte. O device flow não exige client_secret: apenas o
 * client_id do OAuth App, que é público.
 */
export class OAuth {
  constructor({ clientId = null } = {}) {
    this.clientId = clientId;
    this.sessions = new Map();
  }

  get configured() {
    return Boolean(this.clientId);
  }

  /** Guarda o client_id usado em cada pedido, para trocar o código com segurança. */
  #remember(deviceCode, clientId) {
    this.sessions.set(deviceCode, clientId);
    if (this.sessions.size > 20) {
      this.sessions.delete(this.sessions.keys().next().value);
    }
  }

  /**
   * POST form-encoded, como o GitHub documenta (o Accept: application/json
   * pede a resposta em JSON). JSON puro no corpo nem sempre e aceito, e a
   * resposta vem form-encoded quando o Accept nao e lido — daí o fallback.
   */
  async #post(url, fields) {
    const body = new URLSearchParams();
    for (const [key, value] of Object.entries(fields)) {
      if (value !== undefined && value !== null && value !== "") body.set(key, String(value));
    }

    const res = await fetch(url, {
      method: "POST",
      headers: {
        "content-type": "application/x-www-form-urlencoded",
        accept: "application/json",
      },
      body: body.toString(),
    });

    const text = await res.text();
    if (!text) return {};
    try {
      return JSON.parse(text);
    } catch {
      return Object.fromEntries(new URLSearchParams(text));
    }
  }

  /** URL de autorização que o navegador abre para o usuário confirmar. */
  authorizeUrl({ clientId, redirectUri, state, challenge, scope = "repo" }) {
    const url = new URL(AUTHORIZE_URL);
    url.searchParams.set("client_id", clientId);
    url.searchParams.set("redirect_uri", redirectUri);
    url.searchParams.set("scope", scope);
    url.searchParams.set("state", state);
    if (challenge) {
      url.searchParams.set("code_challenge", challenge);
      url.searchParams.set("code_challenge_method", "S256");
    }
    return url.toString();
  }

  /** Inicia o pedido de autorização e devolve o código para o usuário digitar. */
  async start({ clientId, scope = "repo" } = {}) {
    const id = (clientId || this.clientId || "").trim();
    if (!id) {
      const error = new Error(
        "Informe o Client ID do OAuth App do vsx (crie um em https://github.com/settings/developers).",
      );
      error.status = 400;
      throw error;
    }

    const data = await this.#post(DEVICE_CODE_URL, { client_id: id, scope });
    if (data.error) {
      throw new Error(data.error_description || data.error);
    }

    this.#remember(data.device_code, id);

    return {
      deviceCode: data.device_code,
      userCode: data.user_code,
      verificationUri: data.verification_uri,
      expiresIn: data.expires_in || 900,
      interval: data.interval || 5,
    };
  }

  /** Consulta o estado do pedido; o token aparece quando o usuário autoriza. */
  async poll(deviceCode) {
    if (!deviceCode) throw new Error("deviceCode ausente");

    const data = await this.#post(ACCESS_TOKEN_URL, {
      client_id: this.sessions.get(deviceCode) || this.clientId,
      device_code: deviceCode,
      grant_type: GRANT_TYPE,
    });

    if (data.error) {
      return {
        pending: data.error === "authorization_pending" || data.error === "slow_down",
        error: data.error,
        description: data.error_description,
      };
    }

    return {
      pending: false,
      token: data.access_token,
      tokenType: data.token_type,
      scope: data.scope,
    };
  }

  /**
   * Troca o codigo do web flow por um token (com PKCE).
   * O state carrega o verifier gerado no navegador, entao nao ha
   * client_secret em lugar nenhum.
   */
  async exchangeCode({ code, state, clientId, clientSecret, redirectUri, verifier }) {
    const data = await this.#post(ACCESS_TOKEN_URL, {
      client_id: clientId || this.clientId,
      ...(clientSecret ? { client_secret: clientSecret } : {}),
      code,
      redirect_uri: redirectUri,
      ...(verifier ? { code_verifier: verifier } : {}),
    });

    if (data.error) {
      throw new Error(data.error_description || data.error);
    }
    return { token: data.access_token, scope: data.scope, tokenType: data.token_type };
  }
}
